--------------------------------------------------------------------------------------------
Dodo's Great Escape - Lab Breakout
--------------------------------------------------------------------------------------------

Thanks for saving Dodo's!
I hope you enjoy this little run and stay ready for the continuation of Dodo's Journey!

Leave feedback on the page! :)

--------------------------------------------------------------------------------------------